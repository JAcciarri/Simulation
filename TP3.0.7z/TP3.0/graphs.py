import matplotlib.pyplot as plt


def plot_sector(fig, results, title, x_label, y_label):
    ax = fig.add_subplot(2, 2, 1)
    ax.set_title(title)
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    for result in results:
        x, y = zip(*result["avg_num_in_queue"].items())
        ax.plot(x, y)


def line_plot_stats(results):
    fig = plt.figure()

    plot_sector(
        fig, results, title="Demora promedio en cola", x_label="Time", y_label="Q(n)"
    )
    plt.show()

